-- Challenge Bonus queries.
-- 1. (2.5 pts)
-- Retrieve all the number of backer_counts in descending order for each `cf_id` for the "live" campaigns. 

SELECT 
campaign.cf_id, 
SUM(backers_count)

INTO backers_count_table
FROM campaign
WHERE (campaign.outcome = 'live')
GROUP BY campaign.cf_id
ORDER BY SUM(backers_count) DESC;

SELECT * FROM public.backers_count_table




-- 2. (2.5 pts)
-- Using the "backers" table confirm the results in the first query.


SELECT 
backers.cf_id, 
COUNT(backer_id)

INTO backers_id_count_table
FROM backers
INNER JOIN campaign
ON (backers.cf_id = campaign.cf_id)
WHERE (campaign.outcome = 'live')
GROUP BY backers.cf_id
ORDER BY COUNT(backer_id) DESC;

SELECT * FROM public.backers_id_count_table


-- 3. (5 pts)
-- Create a table that has the first and last name, and email address of each contact.
-- and the amount left to reach the goal for all "live" projects in descending order. 

SELECT 
contacts.first_name,
contacts.last_name,
contacts.email,
SUM(goal)-SUM(pledged)as "Remaining Goal Amount"

INTO email_contacts_remaining_goal_amount
FROM contacts
INNER JOIN campaign
ON (contacts.contact_id = campaign.contact_id)
WHERE (campaign.outcome = 'live')
GROUP BY contacts.contact_id
ORDER BY "Remaining Goal Amount" DESC;




-- Check the table
SELECT * FROM public.email_contacts_remaining_goal_amount

-- 4. (5 pts)
-- Create a table, "email_backers_remaining_goal_amount" that contains the email address of each backer in descending order, 
-- and has the first and last name of each backer, the cf_id, company name, description, 
-- end date of the campaign, and the remaining amount of the campaign goal as "Left of Goal". 


SELECT DISTINCT ON (backer_id)
email,
first_name,
last_name,
backers.cf_id,
company_name,
description,
end_date,
SUM(goal)-SUM(pledged)as "Left of Goal"
INTO email_backers_remaining_goal_amount
FROM backers
INNER JOIN campaign
ON (backers.cf_id = campaign.cf_id)
WHERE (campaign.outcome = 'live')
GROUP BY backers.backer_id;


-- Check the table
SELECT * FROM public.email_backers_remaining_goal_amount


